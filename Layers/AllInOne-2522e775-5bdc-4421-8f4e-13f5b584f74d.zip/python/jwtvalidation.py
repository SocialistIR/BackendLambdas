import pymysql
import datetime
import jwt

GLOBAL_SECRET = "YDX2rYsFYAYOa3Lz8vuU8cOxurbFy08nrIdHEUJI"

def is_valid_jwt(token, cursor):
    # Valid structure
    try:
        data = jwt.decode(token, GLOBAL_SECRET, algorithms=['HS256'])
    except Exception as e:
        print(f"Error in decoding token: {e}")
        return (False, "Token is corrupted")
    
    # Expired token
    if data["exp"] < datetime.datetime.now().timestamp():
        return (False, "Token has expired")

    # Check if blacklisted
    cursor.execute("select count(*) from TokenBlacklist where token=%s", (token))
    rows = int(cursor.fetchone()[0]) 
    if rows > 0:
        return (False, "Token has been invalidated")
    return (True, data)

def encode_jwt_payload(payload):
    return jwt.encode(payload, GLOBAL_SECRET, algorithm='HS256').decode()
